import 'package:flutter/material.dart';
import 'package:mayor_menor/core/datos.dart';
import 'package:mayor_menor/provider/provider.dart';
import 'package:provider/provider.dart';

JuegoSing sing = JuegoSing();
//final prov = Provider(create: (context) => Provider.of<ListasProvider>);

void evaluardor(int intento, BuildContext context){
final prov = Provider.of<ListasProvider>(context);
  if (prov.intentosRestantes! > 1){
    if(intento == sing.find){
      print('igual');
      prov.fin.add(intento);
      prov.reset();
      setState(){};
    }else if(intento < sing.find!){
      print('menor');
      prov.menores.add(intento);
      prov.intentosRestantes = prov.intentosRestantes! - 1;
      setState(){};
    } else {
      print('mayor');
      prov.mayores.add(intento);
      prov.intentosRestantes = prov.intentosRestantes! - 1;
      setState(){};
    }
  } else {
    print('falló');
    prov.fin.add(intento);
    prov.reset();
    setState(){};
  }
}