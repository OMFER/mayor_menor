import 'package:flutter/material.dart';

class ListasProvider with ChangeNotifier{
  List<int> _menores = [];
  List<int> _mayores = [];
  List<int> _fin = [];
  int? _intentosRestantes;

  List<int> get menores => _menores;
  List<int> get mayores => _mayores;
  List<int> get fin => _fin;
  int? get intentosRestantes => _intentosRestantes;

  void addMenor(int intento){
    _menores.add(intento);
  }
  void addMayor(int intento){
    _mayores.add(intento);
  }
  void addFin(int intento){
    _fin.add(intento);
  }
  set intentosRestantes(int? value){
    _intentosRestantes = value;
    notifyListeners();
  }

 /* set menores(List<int> intento){
    _menores = intento;
    notifyListeners();
  }
  set mayores(List<int> intento){
    _menores = intento;
    notifyListeners();
  }
  set fin(List<int> intento){
    _menores = intento;
    notifyListeners();
  }*/

  void reset (){
    _menores = [];
    _mayores = [];
  }
}